#include "sensors_data_processing/sensors_data_processing.h"

SensorsData::SensorsData() {

	first_package_subscriber_ = n_.subscribe("/status_first_can", 1, &SensorsData::FirstPackageCallback, this);
	second_package_subscriber_ = n_.subscribe("/status_second_can", 1, &SensorsData::SecondPackageCallback, this);
	third_package_subscriber_ = n_.subscribe("/status_third_can", 1, &SensorsData::ThirdPackageCallback, this);

	sensors_data_publisher_ = n_.advertise<agrobit_msg::sensors>("/status_data", 1);
	
}

void SensorsData::FirstPackageCallback(const agrobit_msg::can_bus& can_bus_msg) {
sensors_data.CO = can_bus_msg.data[0] | ((can_bus_msg.data[1] & 0xF0) << 4);
sensors_data.H2S = (can_bus_msg.data[2] << 4) | (can_bus_msg.data[1] & 0x0F);
sensors_data.NH3 = can_bus_msg.data[3] | ((can_bus_msg.data[4] & 0xF0) << 4);
sensors_data.outside_temperature = (can_bus_msg.data[5] << 4) | (can_bus_msg.data[4] & 0x0F);
sensors_data.lumen = can_bus_msg.data[6] | (can_bus_msg.data[7] << 8);
}

void SensorsData::SecondPackageCallback(const agrobit_msg::can_bus& can_bus_msg) {
sensors_data.IR_temperature = can_bus_msg.data[0] | (can_bus_msg.data[1] << 8);
sensors_data.outside_humidity = can_bus_msg.data[2] | ((can_bus_msg.data[3] & 0xF0) << 4);
sensors_data.pressure = (can_bus_msg.data[4] & 0xFF) | (can_bus_msg.data[5] << 8) | (can_bus_msg.data[6] << 16) | (can_bus_msg.data[7] << 24);
}

void SensorsData::ThirdPackageCallback(const agrobit_msg::can_bus& can_bus_msg) {
sensors_data.CO2 = can_bus_msg.data[0] | (can_bus_msg.data[1] << 8);
sensors_data.inside_temperature = can_bus_msg.data[3] | (can_bus_msg.data[2] << 8);
}


void SensorsData::PublishSensorsDataPackage() {
	agrobit_msg::sensors first_sensors_data_for_pub;
	first_sensors_data_for_pub.NH3 = sensors_data.NH3; //
	first_sensors_data_for_pub.CO = sensors_data.CO;//
	first_sensors_data_for_pub.H2S = sensors_data.H2S;//
	first_sensors_data_for_pub.pressure = (double)sensors_data.pressure / 256.0;
	first_sensors_data_for_pub.lumen = sensors_data.lumen / 1.2;
	first_sensors_data_for_pub.IR_temperature = sensors_data.IR_temperature * 0.02 - 273.15;
	first_sensors_data_for_pub.outside_humidity = (float)sensors_data.outside_humidity * HUMIDITY_COEF;
	first_sensors_data_for_pub.outside_temperature = (float)sensors_data.outside_temperature * TEMPERATURE_COEF - 20;
	first_sensors_data_for_pub.CO2 = sensors_data.CO2;//
	first_sensors_data_for_pub.temperature_inside = (float)sensors_data.inside_temperature * 0.1;//
	sensors_data_publisher_.publish(first_sensors_data_for_pub);
}

void SensorsData::Run() {
	ros::Rate rate(WHEELS_CONTROLLER_RATE_HZ);
	while(ros::ok()) {
		PublishSensorsDataPackage();
		rate.sleep();
		ros::spinOnce();
	}
}





