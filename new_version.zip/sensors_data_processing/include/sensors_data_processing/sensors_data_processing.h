#ifndef WHEELS_CONTROLLER_H_
#define WHEELS_CONTROLLER_H_

#include <ros/ros.h>
#include <cmath>
#include "agrobit_msg/can_bus.h"
#include "agrobit_msg/sensors.h"
#include "std_msgs/UInt16.h"

#define WHEELS_CONTROLLER_RATE_HZ 10
#define HUMIDITY_COEF 0.0265251989389
#define TEMPERATURE_COEF 0.02509915

#define T1 27385
#define T2 25589
#define T3 -1000

struct data{
uint16_t NH3 = 0;
uint16_t CO = 0;
uint16_t H2S = 0;
uint32_t pressure = 0;
uint16_t lumen = 0;
uint16_t IR_temperature = 0;
uint16_t outside_humidity = 0;
uint16_t outside_temperature = 0;
uint16_t CO2 = 0;
uint16_t inside_temperature = 0;
};

class SensorsData {

public:
	SensorsData();
	void Run();
	void FirstPackageCallback(const agrobit_msg::can_bus& can_bus_msg);
	void SecondPackageCallback(const agrobit_msg::can_bus& can_bus_msg);
	void ThirdPackageCallback(const agrobit_msg::can_bus& can_bus_msg);
	
private:
	void Init();
	void PublishSensorsDataPackage();

	ros::NodeHandle n_;
	ros::Subscriber first_package_subscriber_;
	ros::Subscriber second_package_subscriber_;
	ros::Subscriber third_package_subscriber_;
	ros::Publisher sensors_data_publisher_;

	data sensors_data;
};

#endif
